
# Full Platform ERD Outline

## Purpose

This document provides a top-level entity relationship outline for the full NexusBridge institutional platform.

Domains included:

- identity and access
- borrower origination
- document management
- underwriting
- servicing
- ledger
- funds and investors
- compliance and offerings
- tokenization (future)

---

## Identity Domain

- profiles
- organizations
- roles
- organization_members

---

## Borrower Origination Domain

- borrowers
- borrower_entities
- applications
- properties
- loan_requests
- collateral
- guarantors
- income_sources
- bank_accounts
- borrower_credit_reports
- borrower_liabilities

Relationships:

- borrower has many applications
- application has many properties / documents / underwriting cases
- borrower may belong to organization

---

## Document Domain

- documents
- document_versions
- document_requests
- document_extractions
- document_review_flags

---

## Underwriting Domain

- underwriting_cases
- underwriting_decisions
- conditions
- risk_flags
- valuation_reports
- underwriting_rules
- rule_results
- rule_exceptions

---

## Servicing Domain

- loans
- loan_draws
- payment_schedules
- payments
- fees
- delinquencies
- payoffs

---

## Ledger Domain

- ledger_accounts
- ledger_transactions
- ledger_entries

Relationships:

- one ledger_transaction has many ledger_entries
- loans and fund activity post to ledger_transactions

---

## Fund & Investor Domain

- investors
- funds
- subscriptions
- capital_calls
- allocations
- distributions
- investor_statements
- tax_documents
- fund_capital_accounts
- fund_nav_snapshots
- fund_nav_line_items
- fund_waterfall_rules
- fund_waterfall_runs

---

## Compliance / Offering Domain

- offerings
- offering_documents
- offering_updates
- reg_a_investor_limits
- accreditation_records
- suitability_questionnaires
- transfer_restrictions

---

## Operations Domain

- activity_logs
- audit_events
- webhook_events
- notifications
- tasks

---

## Tokenization Domain (Future)

- wallets
- wallet_verifications
- tokenized_interests
- tokenized_transfer_requests
- onchain_transactions
- reserve_attestations
- protocol_events

---

## Suggested Relationship Spine

```text
Profile / Organization
      ↓
   Borrower / Investor
      ↓
Application / Subscription
      ↓
Loan / Allocation
      ↓
Payment / Distribution
      ↓
   Ledger / NAV
      ↓
Statements / Tax Docs / On-Chain Mirror
```

---

## Summary

This ERD outline serves as the master cross-domain map for developers, architects, and auditors. It should be turned into a formal ERD diagram as the next step.
